import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/useAuth';
import PublicLayout from './layouts/PublicLayout';
import LandingPage from './pages/LandingPage';
import Features from './pages/Features';
import ScrollToTop from './components/ScrollToTop';

// Import Pages (formerly in dashboard subfolder)
import Login from './pages/Login';
import Layout from './components/Layout';
import DashboardHome from './pages/DashboardHome';
import Units from './pages/Units';
import Leads from './pages/Leads';
import Customers from './pages/Customers';
import Keuangan from './pages/Keuangan';
import Reminders from './pages/Reminders';
import DokumenCustomer from './pages/DokumenCustomer';
import Cicilan from './pages/Cicilan';
import ProgressPembangunan from './pages/ProgressPembangunan';
import TimSales from './pages/TimSales';
import Approvals from './pages/Approvals';
import Laporan from './pages/Laporan';
import Pricelist from './pages/Pricelist';
import Bookings from './pages/Bookings';
import AfterSales from './pages/AfterSales';
import Legal from './pages/Legal';
import Akuntansi from './pages/Akuntansi';
import Proyek from './pages/Proyek';
import Promos from './pages/Promos';
import BAST from './pages/BAST';
import CustomerPortal from './pages/CustomerPortal';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const auth = useAuth() as unknown as { user: Record<string, unknown> | null };
  const user = auth?.user;
  return user ? children : <Navigate to="/login" />;
}

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
      {/* Public Landing Page */}
      <Route path="/" element={<PublicLayout />}>
        <Route index element={<LandingPage />} />
        <Route path="features" element={<Features />} />
      </Route>

      {/* Dashboard Routes */}
      <Route path="/login" element={<Login />} />
      <Route
        path="/dashboard"
        element={
          <PrivateRoute>
            <Layout />
          </PrivateRoute>
        }
      >
        <Route index element={<DashboardHome />} />
        <Route path="units" element={<Units />} />
        <Route path="leads" element={<Leads />} />
        <Route path="customers" element={<Customers />} />
        <Route path="keuangan" element={<Keuangan />} />
        <Route path="reminders" element={<Reminders />} />
        <Route path="dokumen" element={<DokumenCustomer />} />
        <Route path="cicilan" element={<Cicilan />} />
        <Route path="progress" element={<ProgressPembangunan />} />
        <Route path="timsales" element={<TimSales />} />
        <Route path="approvals" element={<Approvals />} />
        <Route path="laporan" element={<Laporan />} />
        <Route path="pricelist" element={<Pricelist />} />
        <Route path="bookings" element={<Bookings />} />
        <Route path="promo" element={<Promos />} />
        <Route path="portal" element={<CustomerPortal />} />
        <Route path="bast" element={<BAST />} />
        <Route path="after-sales" element={<AfterSales />} />
        <Route path="legal" element={<Legal />} />
        <Route path="akuntansi" element={<Akuntansi />} />
        <Route path="proyek" element={<Proyek />} />
      </Route>
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
    </>
    );
    }

